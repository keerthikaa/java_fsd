package com.test;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class LoginPage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      
		System.setProperty("webdriver.edge.driver", "C:\\Users\\91827\\Desktop\\Projects\\Phase  5\\edgedriver_win64\\edgedriver.exe");
		WebDriver wd = new EdgeDriver();
		wd.get("http://127.0.0.1:5500/LoginPage.html");
		try {
		//email verification
		WebElement emailref = wd.findElement(By.id("n1"));
		WebElement passwordref = wd.findElement(By.id("n2"));
		WebElement submitref = wd.findElement(By.id("b1"));
		submitref.click();Thread.sleep(2000);
		Alert alertref = wd.switchTo().alert(); //give the alert box reference
		System.out.println(alertref); Thread.sleep(2000);//alert box content
		alertref.accept();
	
		
		//password validation
		  /*	WebElement emailref = wd.findElement(By.id("n1"));
				WebElement passwordref = wd.findElement(By.id("n2"));
				emailref.sendKeys("keerthi@gmail.com");Thread.sleep(2000);
				WebElement submitref = wd.findElement(By.id("b1"));
				submitref.click();
				Alert alertref = wd.switchTo().alert(); //give the alert box reference
				System.out.println(alertref);Thread.sleep(2000); //alert box content
				alertref.accept(); 
			*/
		
		//For failure
		/*
	   WebElement emailref = wd.findElement(By.id("n1"));
		WebElement passwordref = wd.findElement(By.id("n2"));
		emailref.sendKeys("keerthikas@gmail.com");
		passwordref.sendKeys("123");Thread.sleep(2000);
		WebElement submitref = wd.findElement(By.id("b1"));
		submitref.click();
		Alert alertref = wd.switchTo().alert(); //give the alert box reference
		System.out.println(alertref); Thread.sleep(2000);//alert box content
		alertref.accept(); 
		*/
		
		/*
		WebElement emailref = wd.findElement(By.id("n1"));
		WebElement passwordref = wd.findElement(By.id("n2"));
		emailref.sendKeys("keerthi@gmail.com");
		passwordref.sendKeys("123");
		Thread.sleep(2000);
		WebElement submitref = wd.findElement(By.id("b1"));
		submitref.click();
		Thread.sleep(2000);
		Alert alertref = wd.switchTo().alert(); //give the alert box reference
		System.out.println(alertref); Thread.sleep(2000); //alert box content
		alertref.accept();
		*/
		
		}catch(Exception e) {
			System.out.println(e);
		}
	}

}
