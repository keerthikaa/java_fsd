package com.test;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class RegisterPage {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.edge.driver", "C:\\Users\\91827\\Desktop\\Projects\\Phase  5\\edgedriver_win64\\edgedriver.exe");
		WebDriver wd = new EdgeDriver();
		wd.get("http://127.0.0.1:5500/RegisterPage.html");
		try {
		WebElement frstname = wd.findElement(By.id("n1"));
		WebElement lastname = wd.findElement(By.id("n2"));
		frstname.sendKeys("KEERTHI");
		lastname.sendKeys("S");
		Thread.sleep(500);
		WebElement course = wd.findElement(By.id("c1"));
		course.sendKeys("EMP@25");
		WebElement gender = wd.findElement(By.name("gender"));
		gender.sendKeys("FEMLAE");Thread.sleep(2000); 
		WebElement phone = wd.findElement(By.name("phone"));
		phone.sendKeys("8907654321");
		WebElement address = wd.findElement(By.name("address"));
		address.sendKeys("124, Town City , Bangalore");Thread.sleep(2000); 
		WebElement emailref = wd.findElement(By.name("email"));
		WebElement passwordref = wd.findElement(By.name("psw"));
		emailref.sendKeys("keerthi@gmail.com");
		passwordref.sendKeys("123");Thread.sleep(2000); 
		
		WebElement register = wd.findElement(By.className("registerbtn"));
		register.click();Thread.sleep(2000); 
		Alert alertref = wd.switchTo().alert(); 
		System.out.println(alertref); Thread.sleep(2000); 
		alertref.accept();
		
		}catch(Exception e) {
			System.out.println(e);
		}
		
	}

}
