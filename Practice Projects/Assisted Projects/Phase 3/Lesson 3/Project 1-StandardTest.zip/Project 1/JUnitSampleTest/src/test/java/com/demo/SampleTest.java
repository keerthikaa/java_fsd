package com.demo;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;

class SampleTest {
	
	@BeforeAll
	public static void BeforeAll() {
		System.out.println("BeforeAll");
	}
	
	
	@BeforeEach
	public void BeforeEach() {
		System.out.println("BeforeEach");
	}
	
	
	@Test
	public void TestOne() {
		System.out.println("My First Sample Test");
	}
	
	
	@Test
	public void TestTwo() {
		System.out.println("My Second Sample Test");
	}
	
	@AfterEach
	public void AfterEach() {
		System.out.println("AfterEach");
	}
	
	@AfterAll
	public static void AfterAll() {
		System.out.println("AfterAll");
	}


	

}
