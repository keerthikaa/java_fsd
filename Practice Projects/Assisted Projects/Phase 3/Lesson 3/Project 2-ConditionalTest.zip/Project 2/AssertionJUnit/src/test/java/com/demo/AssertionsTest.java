package com.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AssertionsTest {
	
	public boolean checkage(int age) {
		return age>=18;
		
	}

	@Test
	public void TestAssertions(){
		
		assertEquals(6,4+2);
		assertNotEquals(8,1+3);
		
		
		assertTrue(checkage(20));
		
		
		int a=90;
		int b=100;
		assertTrue(b>a);
		assertFalse(a>b);
		
		
		String name=null;
		assertNull(name);
		
		String name1="Meha";
		assertNotNull(name1);
		
		
		
		
	}
	
	public void testThrow() {
		assertThrows(RuntimeException.class,()->
				{throw new RuntimeException("not valid");});
		
		assertThrows(ArithmeticException.class,()->
		{int x=10/0;System.out.println(x);});
		
		assertThrows(NullPointerException.class,()->
		{String x=null;System.out.println(x.toLowerCase());});
	}
}
