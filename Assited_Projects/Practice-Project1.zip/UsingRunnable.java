package Programs;

class Task implements Runnable{
	@Override
	public void run() {
		Thread tt =Thread.currentThread();
		String name = tt.getName();
		for(int i=0;i<10;i++) {
			System.out.println(name + "=" + i);
		}
		}
}
public class UsingRunnable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread tt = Thread.currentThread();
		Runnable t = new Task();
		Thread t1=new Thread(t);
		Thread t2=new Thread(t);
		System.out.println(tt);
		t1.setName("First");
		t2.setName("Second");
		t1.start();
		t2.start();		
	}

}
