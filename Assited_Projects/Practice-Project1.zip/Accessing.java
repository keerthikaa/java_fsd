package Programs;

public class Accessing extends Accessmodifier {
	public void display() {
		//accessing from sub class 
		System.out.println("This is sub class");
		System.out.println("b = " + b);
		System.out.println("c = " + c);
		System.out.println("d = " + d);
	}

}
