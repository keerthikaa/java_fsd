package Programs;
import java.util.Stack;

public class StackExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Stack ss = new Stack();
     ss.push(100);
     ss.push(200);
     ss.push(300);
     ss.push(400);
     ss.push(500);
     ss.push(600);
     System.out.println("The elements in stack are :");
     System.out.println(ss);
     System.out.println("Removing the last element :");
     System.out.println(ss.pop());
     System.out.println(ss);
     System.out.println("Adding element  in  the stack:");
     ss.push(1200);
     System.out.println(ss);
}
}
