package Programs;

public class Accessmodifier {
	
	private int a =10;
	int b =30;
	protected int c=50;
	public int d=55;


public void dis() {
	System.out.println("Main class");
	System.out.println("A " + a);
	System.out.println("B " + b);
	System.out.println("C " + c);
	System.out.println("D " + d);

}
}