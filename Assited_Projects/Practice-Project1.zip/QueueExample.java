package Programs;

import java.util.Queue;
import java.util.LinkedList;
public class QueueExample {

	public static void main(String[] args) 
	{
	     Queue<String>  City = new LinkedList<>();
	     City.add("Kolkata");
	     City.add("Patna");
	     City.add("Delhi");
	     City.add("Pune");
	     City.add("Noida");
	System.out.println("Queue is : " + City);
	        		System.out.println("Head of Queue : " +City.peek());
	        		City.remove();
	        		System.out.println("After removing Head of Queue : " + City);
	        		
	    	}
	
}
