package Programs;

class A extends Thread{
	public void run() {
		for(int i=0;i<10;i++) {
			System.out.println("i" + i);
		}
	}
}

class B extends Thread{
	public void run() {
		for(int i=0;i<5;i++) {
			System.out.println("j" + i);
		}
	}
}
public class UsingThreadExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A obj1 = new A();
		B obj2 = new B();
		obj1.run();
		obj2.run();
		

	}

}
