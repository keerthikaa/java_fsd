package Programs;
import java.util.*;
public class Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner ob = new Scanner(System.in);
		System.out.println("Single dimensional array") ;
		System.out.println("Enter number of Elements : ");
		int n = ob.nextInt();
		int abc[] =new int[n];	
		
		for(int i=0;i<abc.length;i++) {
			System.out.println("Enter number " + (i+1));
			abc[i] =ob.nextInt();
			
		}
		System.out.println("All Elements are");
		for(int m :abc) {
			System.out.println(m);
		}
		
		

	}

}
