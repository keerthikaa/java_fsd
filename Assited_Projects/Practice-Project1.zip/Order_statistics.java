package Programs;
import java.util.Arrays;
import java.util.Collections;

class Order_statistics {
	
	public static int SmallestElement(Integer[] arr,
								int n)
	{
		
		Arrays.sort(arr);
		System.out.println("Array in sorted order :");
		for (int i : arr) {
			System.out.println(i);
		}
		return arr[n - 1];
		}


	public static void main(String[] args)
	{
		Integer arr[] = new Integer []{ 12, 3, 5, 7, 19 ,7,60 };	
		int n = 4;
		System.out.println("Array Elements are :");
		for (int i : arr) {
			System.out.println(i);
		}
		System.out.print("The 4th smallest element is " + SmallestElement(arr, n));
	}
}



