package Programs;
import java.util.*;

public class Collection_list {
	public static void main(String[] args) {
			
			System.out.println("Create ArrayList : ");
			ArrayList<String> food=new ArrayList<String>();   
		      food.add("Idly");
		      food.add("Dosa");  
		      food.add("Vegetable Rice");   
		      System.out.println(food);  
			
		      System.out.println("\n");
		      System.out.println("Create Vector :");
		      Vector<Integer> vc = new Vector<Integer>();
		      vc.addElement(15); 
		      vc.addElement(5); 
		      vc.addElement(1); 
		      vc.addElement(30); 
		      System.out.println(vc);			      
		       
		     
		       System.out.println("\n");
		       System.out.println("Create HashSet :");
		       HashSet<Integer> set=new HashSet<Integer>();  
		       set.add(10);  
		       set.add(13);  
		       set.add(12);
		       set.add(14);
		       System.out.println(set);
		       
		       
		       System.out.println("\n");
		       System.out.println("Create LinkedHashSet :");
		       LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
		       set2.add(11);  
		       set2.add(13);  
		       set2.add(12);
		       set2.add(14);	       
		       System.out.println(set2);
		      	} 
		      }  
		
