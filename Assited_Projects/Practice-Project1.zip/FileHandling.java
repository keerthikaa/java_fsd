package Programs;
	import java.io.File;
	import java.io.FileOutputStream;
	import java.io.FileWriter;
	import java.io.IOException;
	import java.nio.charset.StandardCharsets;
	import java.nio.file.Files;
	import java.nio.file.Paths;
	import java.nio.file.StandardOpenOption;
	import java.util.Arrays;
	import java.util.List;
	 
	public class FileHandling {
	    public static void main(String[] args) throws IOException
	    {
	        FileClass();
	       
	    }
	 
	    private static void FileClass() throws IOException
	    {
	          File file = new File("c:\\Users\\91827\\eclipse-workspace\\welcome\\src\\Programs\\filename.txt");
	  
	         //System.out.println("File1 :");
	          System.out.println("filename :");
	          if (file.createNewFile()){
	            System.out.println("Thus , the File is created!");
	          }else{
	            System.out.println("File already exists.");
	          }
	           
	     
	          FileWriter writer = new FileWriter(file);
	          writer.write("Data is added");
	          writer.close();
	          
	          System.out.println("\n");
	          String path = System.getProperty("user.dir") + "\\src\\Programs\\filename.txt";
	          
	          String text = "Added text";
	         
	        	  try {
	                  Files.write(Paths.get(path), text.getBytes(), StandardOpenOption.APPEND);
	              } catch (IOException e) {
	              }
	          }
	          
	         
	    }

