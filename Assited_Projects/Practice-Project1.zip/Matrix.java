package Programs;

public class Matrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

int a[][]={{1,2,1},{2,5,2},{2,3,3}};    
int b[][]={{1,4,1},{1,2,2},{1,3,4}};      
int c[][]=new int[3][3];   
System.out.println("The matrixx multiplication are :");
for(int i=0;i<3;i++){    
for(int j=0;j<3;j++){    
c[i][j]=0;      
for(int k=0;k<3;k++)      
{      
c[i][j]+=a[i][k]*b[k][j];      
}
System.out.print(c[i][j]+" ");  
}
System.out.println();
}    
}}  