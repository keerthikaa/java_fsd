package Programs;

import java.util.Scanner;



public class Range_prblm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int start , end ;
		int sum=0;int i;
		System.out.println("Enter the Range:");
		System.out.println("Enter the start element:");
		start =sc.nextInt();
		System.out.println("Enter the End element:");
		end =sc.nextInt();	
 
        for (i=start;i<=end;i++) {
	       sum =sum+i;
         }
  System.out.println("The sum of n elements in the range are :" + sum);
}
}
