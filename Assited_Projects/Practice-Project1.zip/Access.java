package Programs;

public class Access {
	public static void main(String[] args)
	{   System.out.println("This is main method");
	 System.out.println("Access modifiers");
		Accessmodifier ac = new Accessmodifier();
		ac.dis();
		Accessing as = new Accessing();
		as.display();
		
		}

}
