package Programs;

public class Try_Catch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Try and Catch example");
		int a=10;
		int b=0;
		try {
			int res = a/b;
			System.out.println ("Result " + res);
		} catch (Exception e) {
			System.out.println("Error");
			
			System.out.println(e.getMessage());
			System.out.println(e.toString());
		}
		System.out.println("Finish");
	}

}
