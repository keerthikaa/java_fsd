package Programs;
import java.util.regex.*;

public class Regex_Example {
	public static void main(String[] args) {

		String pattern = "[a-z]+";
		String check = "JavA is a PrograMminG LanGuAge";
		Pattern p = Pattern.compile(pattern);
		Matcher ch = p.matcher(check);
		
		System.out.println("Checks  for lower case");
		while (ch.find())
	      	System.out.println( check.substring( ch.start(), ch.end() ) );
		
	String pattern2 = "[A-Z]+";
	String check1 = "cOMPUteR Is An ELECtroNIc MaCHInE ";
	Pattern ph = Pattern.compile(pattern2);
	Matcher c = ph.matcher(check1);
	
	System.out.println("\nChecks  for Upper case");
	while (c.find())
      	System.out.println( check1.substring( c.start(), c.end() ) );
	
	
	
	}
	}
