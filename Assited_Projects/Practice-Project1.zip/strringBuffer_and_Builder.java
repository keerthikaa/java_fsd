package Programs;

public class strringBuffer_and_Builder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str1 ="Java";
		String str2 = "Programming";
		System.out.println("Concat :");
		System.out.println(str1+str2);
		System.out.println("Lowercase :");
		System.out.println(str1.toLowerCase());
		System.out.println("Uppercase :");
		System.out.println(str2.toUpperCase());
		System.out.println("\nConversions of String to StringBuffer");
		String str = "HelloWorld";
		StringBuffer sbr = new StringBuffer(str); 
        sbr.reverse(); 
        System.out.println("String to StringBuffer:");
        System.out.println(sbr); 
        StringBuilder sbl = new StringBuilder(str); 
        sbl.append("Welcome"); 
        System.out.println("String to StringBuilder:");
        System.out.println(sbl);              


		
		

	}

}
