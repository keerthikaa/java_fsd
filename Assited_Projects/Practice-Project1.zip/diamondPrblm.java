package Programs;

interface First {  
    default void show() 
    { 
        System.out.println(" First Method "); 
    } 
} 
interface Second {  
    default void show() 
    { 
        System.out.println(" Second Method "); 
    } 
}  
public class diamondPrblm implements First, Second 
{  
    public void show() 
    {  
        First.super.show(); 
        Second.super.show(); 
    } 
    public static void main(String args[]) 
    { 
    	diamondPrblm obj = new diamondPrblm(); 
        obj.show(); 
    } 
}


		// TODO Auto-generated method stub

	
