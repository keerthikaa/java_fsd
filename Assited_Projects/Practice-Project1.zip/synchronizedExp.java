package Programs;


class BookTask implements Runnable{
	 int av=1;
	 @Override
	 public synchronized  void run() {
		 Thread t = Thread.currentThread();
		 String name=t.getName();
		 if(av==1) {
			 System.out.println("Congrats...." + name +",U Got tickett");
			 av =av-1;
		 }
		 else {
			 System.out.println(name +" ,there is no ticket available");
		 }
	 }
	 
}
public class synchronizedExp {
	public static void main(String[] args) {
		
    BookTask b1=new BookTask();
    Thread t1 =new Thread(b1);
    Thread t2 =new Thread(b1);
    Thread t3 =new Thread(b1);
     t1.setName("Rajj");
     t2.setName("Ram");
     t3.setName("Rajesh");
     t1.start();
     t2.start();
     t3.start();
	}

}


