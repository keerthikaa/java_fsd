package Programs;
import java.util.*;

public class Map_Example {
		public static void main(String[] args) {
		   	HashMap<Integer,String> ha=new HashMap<Integer,String>();      
		      ha.put(1,"Chennai");    
		      ha.put(2,"Bangalore");    
		      ha.put(3,"Madurai");  
		      ha.put(4,"Kolkata"); 
		      ha.put(5,"Ooty"); 
		       
		      System.out.println("\nThe elements of Hashmap are ");  
		      for(Map.Entry m:ha.entrySet()){    
		       System.out.println(m.getKey()+" "+m.getValue());    
		      }
		      
		      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
		      map.put(1,"Apple");
		      map.put(2,"Tomato"); 
		      map.put(3,"Banana"); 
		      map.put(4,"Carrot");  
		      map.put(5,"Orange"); 
		      map.put(6,"Betroot");       
		      
		      System.out.println("\nThe elements of TreeMap are ");  
		      for(Map.Entry l:map.entrySet()){    
		       System.out.println(l.getKey()+" "+l.getValue());    
		      }    

		}
}
