package Programs;

public class Inner_Class {
		private String msg="Inner Class Message";

		 void display(){  
			 System.out.println("Inside the Super Class\nThis is method method");
			 System.out.println("\n");
			 class Inner{  
				 void msg(){
					 System.out.println("Inside the inner class");
					 System.out.println(msg);
				 }  
		  }  
		  
		  Inner l=new Inner();  
		  l.msg();  
		 }  

		 
		public static void main(String[] args) {
			Inner_Class  ob=new Inner_Class();  
			ob.display();  
			}
	}

